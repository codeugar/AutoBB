console.log("Background service worker started");
